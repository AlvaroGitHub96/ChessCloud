<?php
$page_title = 'Page Not Found';
include(APP_PATH . 'pages/header.php');
?>
<h1>Page Not Found</h1>
<p>Would you like to go to the <a href="">homepage</a>?</p>
<?php
include(APP_PATH . 'pages/footer.php');
?>