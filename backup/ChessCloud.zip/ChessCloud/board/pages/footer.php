</div><!-- end div.twelve.columns -->
</div><!-- end div#body_container -->
<div id="footer">
<div class="row">
  <div class="six columns" id="left_footer">
    <p><?php echo PROJECT_NAME; ?> is released under the <a href="https://github.com/oakmac/chessboardjs/blob/master/LICENSE.md">MIT License</a></p>
    <p><a href="https://github.com/oakmac/chessboardjs/">GitHub</a></p>
  </div>
  <div class="six columns" id="right_footer">
    <a href="">Home</a>
    <a href="examples">Examples</a>
    <a href="docs">Docs</a>
    <a href="download">Download</a>
  </div>
</div>
</div><!-- end div#footer -->
</body>
</html>
