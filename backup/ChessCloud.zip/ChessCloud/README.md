# ChessCloud
TFG of Álvaro Navarro López-Menchero
